<?php
    
    header("location: /admin/panel/index.php");
     
?>