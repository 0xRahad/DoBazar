<?php include("includes/header.php");  ?>

<main>

    <?php
        
        header("location: category/add_category.php");
         
    ?>
    

</main>


<?php  include("includes/footer.php")  ?>