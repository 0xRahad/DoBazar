-- MariaDB dump 10.19  Distrib 10.6.12-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: devt_user
-- ------------------------------------------------------
-- Server version	10.6.12-MariaDB-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` VALUES (7,'rahsec','rahad@gmail.com','$2y$10$YarerdxXKMXBsmzS/o.YJOuQ/H1/CtB4t.354q.i8EN62QYbTfjUC');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `table_cat`
--

DROP TABLE IF EXISTS `table_cat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `table_cat` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `catName` varchar(255) NOT NULL,
  `catDesc` varchar(255) NOT NULL,
  `catImg` varchar(255) NOT NULL,
  `catStatus` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `table_cat`
--

LOCK TABLES `table_cat` WRITE;
/*!40000 ALTER TABLE `table_cat` DISABLE KEYS */;
INSERT INTO `table_cat` VALUES (50,'iphone','iphone 14 pro max','iphonejpg.jpg','true'),(51,'Redmi','This is redmi phone category','redmi.png','true'),(52,'Men Clothes','men products','dress.jpg','true'),(53,'Women Clothes','women products','2.jpg','true');
/*!40000 ALTER TABLE `table_cat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `table_product`
--

DROP TABLE IF EXISTS `table_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `table_product` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `cat_id` int(255) NOT NULL,
  `pName` varchar(255) NOT NULL,
  `pDesc` varchar(255) NOT NULL,
  `pImage` text NOT NULL,
  `pPrice` int(255) NOT NULL,
  `pStatus` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `table_product`
--

LOCK TABLES `table_product` WRITE;
/*!40000 ALTER TABLE `table_product` DISABLE KEYS */;
INSERT INTO `table_product` VALUES (17,52,'Stylish shirt for boys','This is a cotton clothes. this is very peaceful.','15a-1-600x600.jpg',600,'true'),(18,52,'Red Stylish shirt for boys','This is a cotton clothes. this is very peaceful.','532757f2c94cd5174da0c3b2b0ec9587.jpg',600,'true'),(19,52,'Matte Black Stylish shirt for boys','This is a cotton clothes. this is very peaceful.','720e7735511f3026276937fa1e7a7868.jpg_750x400.jpg_.webp',580,'true'),(20,52,'Chek Stylish shirt for boys','This is a cotton clothes. this is very peaceful.','0476676_mens-full-sleeve-cotton-casual-shirt.jpeg',450,'true'),(21,52,'Casual Stylish shirt for boys','This is a cotton clothes. this is very peaceful.','web1-72.jpg',500,'true'),(22,53,'White cute three piece for girl','This is a cotton clothes. this is very peaceful.','3123d0.jpg',600,'true'),(23,53,'Pink cute three piece for girl','This is a cotton clothes. this is very peaceful.','123126037.jpg',1200,'true'),(24,53,'Orange color three piece for womens','This is a cotton clothes. this is very peaceful.','12312.jpeg',1800,'true'),(25,53,'Light pink cute three piece for girl','This is a cotton clothes. this is very peaceful.','123123pg.jpg',1660,'true'),(26,53,'Brown three piece for womens','This is a cotton clothes. this is very peaceful.','efebfb62312306f10e1.jpg',1900,'true');
/*!40000 ALTER TABLE `table_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `table_user`
--

DROP TABLE IF EXISTS `table_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `table_user` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `table_user`
--

LOCK TABLES `table_user` WRITE;
/*!40000 ALTER TABLE `table_user` DISABLE KEYS */;
INSERT INTO `table_user` VALUES (1,'1','1','1','1','1','1'),(2,'1','rahad','rahad@gmail.com','rahad123','1','1'),(3,'','rahadsec','rahadsec@gmail.com','rahad123','','');
/*!40000 ALTER TABLE `table_user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-12-08 13:51:26
